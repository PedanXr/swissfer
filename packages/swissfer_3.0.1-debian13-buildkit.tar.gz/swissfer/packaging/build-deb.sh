#!/bin/sh
set -eu
umask 022
cd "$(dirname "$0")/.."
version=3.0.1-1~deb13u1
arch=$(dpkg --print-architecture)
export OPENSSL_NO_VENDOR=1
cargo build --release --locked
cargo test --locked
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
install -Dm755 target/release/swissfer "$stage/usr/bin/swissfer"
strip --strip-unneeded "$stage/usr/bin/swissfer"
install -Dm644 README.md "$stage/usr/share/doc/swissfer/README.md"
install -Dm644 LICENSE "$stage/usr/share/doc/swissfer/copyright"
install -Dm644 packaging/README.Debian "$stage/usr/share/doc/swissfer/README.Debian"
mkdir -p "$stage/DEBIAN" "$stage/usr/share/man/man1"
gzip -n -9 -c packaging/swissfer.1 > "$stage/usr/share/man/man1/swissfer.1.gz"
mkdir -p debian
cat > debian/control <<CONTROL
Source: swissfer
Section: net
Priority: optional
Maintainer: Local Package Builder <builder@localhost>

Package: swissfer
Architecture: any
Description: Command-line client for SwissTransfer
CONTROL
shlibs=$(dpkg-shlibdeps -O -e"$stage/usr/bin/swissfer" | sed -n 's/^shlibs:Depends=//p')
test -n "$shlibs"
cat > "$stage/DEBIAN/control" <<CONTROL
Package: swissfer
Version: $version
Section: net
Priority: optional
Architecture: $arch
Maintainer: Local Package Builder <builder@localhost>
Depends: $shlibs, ca-certificates
Installed-Size: $(du -sk "$stage/usr" | cut -f1)
Homepage: https://github.com/Blutsh/swissfer
Description: Command-line client for SwissTransfer
 Upload files and folders to SwissTransfer and download shared transfers.
 Unofficial client, not affiliated with Infomaniak.
CONTROL
(cd "$stage" && find usr -type f -print0 | LC_ALL=C sort -z | xargs -0 md5sum > DEBIAN/md5sums)
export SOURCE_DATE_EPOCH=$(git log -1 --format=%ct)
find "$stage" -print0 | xargs -0 touch -h -d "@$SOURCE_DATE_EPOCH"
find "$stage" -type d -exec chmod 755 {} +
out=${1:-../artifacts}
mkdir -p "$out"
dpkg-deb --root-owner-group --build "$stage" "$out/swissfer_${version}_${arch}.deb"
